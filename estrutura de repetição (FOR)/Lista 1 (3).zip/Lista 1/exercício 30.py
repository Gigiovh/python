#30 - Foi feita uma pesquisa entre os habitantes de uma região. Foram coletados os dados de idade, sexo (M/F) e salário.
# Desenvolva um programa que informe:
#a média de salário do grupo; maior e menor idade do grupo;
# quantidade de mulheres com salário até R$100,00. Encerre a entrada de dados quando for digitada uma idade negativa.
s=0
so=0
for c in range (1,5):

    sex=str(input('Digite o seu sexo, sendo (m) para masculino e (f) para feminino:'))
    sa = float(input('Digite o seu salário:'))
    id= int(input('Digite seu salário:'))

    if id>0:
        so=so+sa
    elif sex==('f') and id<101:
        s=s+1

m=so/5

print('A méida do salário é:{} \n A quantidade de mulheres é:{} \n a maior idade é {}\n a menor idade é {}'(m,s))
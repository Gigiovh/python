# inteiro
n1=int(input('Digite um número inteiro:'))
n2=int(input('Digite um número inteiro:'))
if n1>n2:
    print('O primeiro número é maior!')
elif n1<n2:
    print('O segundo número é maior!')
else:
    print('Os dois contêm o mesmo valor.')
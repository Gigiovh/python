# Desenvolva um programa que leia o sexo (Masculino / Feminino) e
# o salário de 15 pessoas, calcule e exiba a média dos salários dos homens e das mulheres.
r=0
q=0
p=0
s=0
for c in range (1,16):

    sex=str(input('Digite o seu sexo, sendo (m) para masculino e (f) para feminino:'))
    sa = float(input('Digite o seu salário:'))

    if sex==('m'):
        s=s+sa
        r=r+1

    elif sex==('f'):
        p=s+sa
        q=q+1

if q==0:
    print('Não há mulheres')
else:
    mm=p/q
    print('A média salarial das mulheres é:{}'.format(mm))

if r==0:
    print('não há homens!')
else:
    h=s/r
    print('A média dos homens é {}'.format(h))
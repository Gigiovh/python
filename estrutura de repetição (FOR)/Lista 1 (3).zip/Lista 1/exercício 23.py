#  Desenvolva um programa que leia 50 números inteiros, conte quantos são divisíveis por 3 e exiba o resultado.
s=0
for c in range (1,51):
    n1=float(input('Digite um número:'))
    if n1% 3 == 0:
        s= s+1

print('A quantidade de números divisíveis por 3 é:{}'.format(s))
#33 - Crie um programa que leia o ano de nascimento de sete pessoas.
# No final, mostre quantas pessoas ainda não atingiram a maioridade e quantos já são maiores de idade.
s=0

for c in range (1,2):
    n1=int(input('Digite o seu ano de nascimento'))
    nas=int(input('Digite o  ano de nascimento atual'))
    t=nas-n1
    if t>17:
        s=s+1
    else:
        mn=s+1

print('Já atingiram a maioridade:{}'.format(s)
print('Já atingiram a maioridade:{}'.format(mn))


#Crie um programa que calcule a soma entre todos os números ímpares que são múltiplos de três
# e que se encontram no intervalo de 1 até 500.
s=0
for c in range(1,501):
    n1=float(input('Digite um número:'))
    if n1%2!=0 and n1%3==0:
        s=s+n1


print('A soma dos números divisíveis por 3 e ímpares é: {}'.format(s))
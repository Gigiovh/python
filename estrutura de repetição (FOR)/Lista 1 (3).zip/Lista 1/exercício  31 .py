#31 - Num frigorífico existem 90 bois. Cada boi traz em seu pescoço um cartão contendo um número de identificação
# e seu peso. Escrever um algoritmo e o fluxograma em Pascal que leia o cartão e o peso dos 90 bois
# ao final imprima o número e o peso do boi mais gordo e dos bois mais magro.

for c in range (1,91):
    pe=float(input('Digite o peso do boí:'))
    id=float(input('Digite o número de indentificação do boí:'))
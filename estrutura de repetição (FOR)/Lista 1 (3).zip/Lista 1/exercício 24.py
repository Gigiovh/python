#Desenvolva um programa que leia 40 números reais,
# somar e calcular a média dos números positivos e contar os números negativos e exiba os resultados.
qn=0
sn=0
q=0
s=0
for c in range (1,41):
    n1=float(input('Digite um número :'))
    if n1>-1:

        q=q+1
        s=s+n1

    elif n1<0:
        qn = qn + 1
        sn=sn+n1


m = s / q
mn = sn / qn

print('A média dos positivos é:{} \n O contar dos positivos é:{}\n sua soma é: {}'.format(m,q,s))

print('A média dos negativos é:{} \n O contar é:{}\n sua soma é: {}'.format(mn,qn,sn))


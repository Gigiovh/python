#25 - Desenvolva um programa que leia o nome e a idade de 20 pessoas, calcule e exiba a média das idades.

s=0
for c in range (1,21):

    nm=str(input('Digite seu nome:'))
    id=int(input('Digite sua idade:'))
    s=s+id

m= s/20
print('A média das idades é:{}'.format(m))
#Qual é o maior dos 3? Armazenamento
n1=float(input('Digite um número: '))
n2=float(input('Digite um número : '))
n3=float(input('Digite um número : '))
if n1>n2 and n1>n3:
    M:n1
elif n1 < n2 and n2 < n3:
    M:n3
elif n1 < n2 and n2 > n3:
    M:n2
else:
    print(INVÁLIDO)
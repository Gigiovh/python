nm=str(input('Digite o nome da capital do Brasil:'))
if nm==('BRASÍLIA'):
    print('PARABÉNS')
elif nm==('Brasília'):
    print('PARABÉNS')
else:
    print('ERROU')
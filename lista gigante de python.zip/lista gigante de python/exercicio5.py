n1=float(input('Digite um número:'))
p=n1%2
if p==0:
    print('O número é par!!')
else:
    print('O número é Ímpar')

if n1>0:
    print('O número é positivo!!')
else:
    print('O número é negativo')

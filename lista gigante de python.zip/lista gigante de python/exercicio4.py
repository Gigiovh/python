n1=float(input('Digite um número:'))
n2=float(input('Digite um número:'))
n3=float(input('Digite um número:'))
n4=float(input('Digite um número:'))
q1=n1**2
q2=n2**2
q3=n3**2
q4=n4**2
if q3>1000 or q3==1000:
    print('O quadrado do terceiro é:{}'.format(q3))
else:3

    print('O quadrado do 1 número é:{} \n O quadrado do segundo número é:{}\n O quadrado do terceiro número é:{} \n O quadrado do quarto número é:{}'.format(q1,q2,q3,q4))
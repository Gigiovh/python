n1=float(input('Digite um número:'))
d=n1%5
di=n1%2
div=n1%10
if d==0 or d==0:
    print('O número é dívisivel por 5')
elif di == 0 or di== 0:
    print('O número é dívisivel por 2')
elif div == 0 or div == 0:
    print('O número é dívisivel por 10')
elif di==0 and d==0 and d==0 and di==0:
    print('O número é dívisivel por 5 e por 3')
elif di == 0 and d == 0 and d ==0 and di == 0 and div==0 and div==0:
    print('O número é dívisivel por 5 e por 2 e por 10')
else:
    print('O número é não é dívisivel por 5 nem por 2, nem por 10')
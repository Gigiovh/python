n1=float(input('Digite um número:'))
n2=float(input('Digite um número:'))
a=n1+n2
if n1>10:
    print('O número é maior que 10')
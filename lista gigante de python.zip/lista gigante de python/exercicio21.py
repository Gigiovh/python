#Ordem decrescente
n1=float(input('Digite um número: '))
n2=float(input('Digite um número : '))
if n1>n2:
    print('A ordem decrescente dos números é  {}, {}'.format(n1,n2))
elif n1 < n2:
    print('A ordem decrescente dos números é  {}, {}'.format(n2, n1))
else:
    print('A ordem decrescente dos números é  {}, {}'.format(n1, n2))
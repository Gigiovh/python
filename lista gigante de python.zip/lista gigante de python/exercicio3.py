C=int(input('Digite o código do funcionário:'))
N=int(input('Digite o número de horas trabalhadas:'))
S=N*10
if N>50:
    E=(N-50)*20
else:
    E=0



print('O valor do salário é de:{}\n com as horas excedidas o valor fica em:{}'.format(S,E))
P=float(input('Digite o índice de poluição:'))
if P>0.04 and P<0.25:
    print('O índice de poluição é aceitável')
elif P>0.2 and P<0.4:
    print('As empresas do 1 grupo devem parar com suas atividades')
elif P > 0.3 and P < 0.5:
    print('As empresas do 1 e 2 grupo devem parar com suas atividades')
elif P ==0.5 or P>0.5:
    print('As empresas do 1, 2 e 3 grupo devem parar com suas atividades')
else:
    print('O valor não está programado no sistema')
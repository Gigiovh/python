n1=float(input('Digite um número:'))
d=n1%5
di=n1%3
if d==0 and di==0:
    print('O número é dívisivel por 5 e por 3')
elif d==1 and di==1:
    print('O número é dívisivel por 5 e por 3')
elif d!=0 and di!=1 and d!=1 and di!=0:
    print('O número é não é dívisivel por 5 nem por 3')
else:
    print('Número inválido ')
nm=str(input('Digite o seu nome: '))
p1=int(input('Digite a nota da primeira prova: '))
p2=int(input('Digite a nota da segunda prova: '))
M=(p1+p2)/2
if M>7 or M==7:
    print('AP na prova final')
else:
    print('RP na prova final')


if p1>7 or p1==7:
    print('AP na primeira prova')
else:
    print('RP na primeira prova')


if p2>7 or p2==7:
    print('AP na segunda prova')
else:
    print('RP na segunda prova')
n1=float(input('Digite um número:'))
if n1>20 and n1<90:
	print('O número está contido entre 20 e 90 ')
else:
    print('O número não está contido entre 20 e 90 ')
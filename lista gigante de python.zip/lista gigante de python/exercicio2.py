P=float(input('Digite o peso do seu peixe:'))
E=P-50
M=E*4
if P>50:
    print('Você deve pagar uma multa de:{}'.format(M))
else:
    print('Zero')
n1=float(input('Digite um número:'))
if n1>20:
    print('O número é maior que 20')
else:
    print('O número é menor que 20')
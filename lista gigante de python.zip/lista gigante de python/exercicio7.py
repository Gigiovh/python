P=int(input('Digite a idade do nadador:'))
if P>4 and P<8:
    print('O nadador está classificado em: Infantil A')
elif P>7 and P<12:
    print('O nadador está classificado em: Infantil B')
elif P >11 and P < 14:
    print('O nadador está classificado em: Juvenil A')
elif P ==13 and P>18:
    print('O nadador está classificado em: Juvenil B')
else:
    print('O nadador está classificado em: Adulto')
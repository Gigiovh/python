#iguais oun diferentes?
n1=float(input('Digite um número: '))
n2=float(input('Digite um número : '))
if n1==n2:
    print('Os números são iguais ')
else:
    print('Os números são diferentes')
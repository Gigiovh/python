n1=float(input('Digite um número:'))
d=n1%5
if d==0:
    print('O número é dívisivel por 5')
elif d==1:
    print('O número é dívisivel por 5')
else:
    print('O número é não é dívisivel por 5')
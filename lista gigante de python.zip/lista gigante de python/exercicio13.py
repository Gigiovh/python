n1=float(input('Digite um número:'))
n2=float(input('Digite um número:'))
d=n1%n2
if d==0 :
	print('O primeiro número é divísivel pelo segundo')
else:
    print('O primeiro número não é divísivel pelo segundo')
#passagem
v=float(input('Digite a  distância da sua viagem em Km/h:'))
if v <= 200:
  print('O valor da sua passagem será de:R$0,50')
else:
  print('O valor da sua passagem será de:R$0,45')
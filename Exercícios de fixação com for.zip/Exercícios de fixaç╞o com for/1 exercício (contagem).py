for cont in range (30,0,-1):
    print(cont)

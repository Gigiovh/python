for cont in range (1,101):
    if cont % 2==0:
        print(cont)
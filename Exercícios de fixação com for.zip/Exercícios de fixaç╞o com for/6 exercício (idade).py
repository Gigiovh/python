s = 0
for cont in range(1,7):
    n1=float(input('Digite sua idade:'))
    s = s+n1

m= s/6
print(m)